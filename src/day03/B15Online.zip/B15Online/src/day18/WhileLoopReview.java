package day18;

public class WhileLoopReview {
    public static void main(String[] args) {

        int x = 10;
        while (x > 5) {
            System.out.println(x+ " is more than 5");
            --x;
        }
        System.out.println("The End");
    }
}
