package day17;

public class WhileLoopFlow {
    public static void main(String[] args) {

        // if loop condition is false then it will not even bother  to enter the loop

        int x = 10;
        while (x>100){
            System.out.println("WOLA!");
            x++;
        }
        System.out.println("THE END");
    }
}
