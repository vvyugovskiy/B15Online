package day04;

public class ArithmeticOperator {
    public static void main(String[] args) {

        System.out.println(5 + 3d);
        System.out.println(5 - 3d);
        System.out.println(5 * 3d);
        System.out.println(5 / 3f);


        //store above numbers in variables
        //and replace above statements with variables instead
        // dataType ressult1 = the calculation here
        //system.out.println(ressult1);

        int num1 = 5;
        double num2 = 3d;
        float num3 = 9f;

        double result1 = num1 + num2;
        double result2 = num1 - num2;
        double result3 = num1 / num2;
        double result4 = num1 * num2;

        System.out.println(result1+";"+result2+";"+result3+";"+result4);










    }
}
