package day04;

public class AmazonEX {
    public static void main(String[] args) {

        String productName = "Fire";
        String model = "HD";
        int version = 8;
        float price = 79.99f;

        System.out.println("I saw "+productName+" "+model+version+" hands-free with Alexa for $"+price);
    }
}
