package day04;

public class Celsius {
    public static void main(String[] args) {

        double F = 90d;
        double C;

        C=(5.0/9)*(F-32);

        System.out.println(F + " in Fahrenheit Is " + C + "C");

    }
}
