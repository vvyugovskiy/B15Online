package day04;

public class StringPractice {
    public static void main(String[] args) {

        String firstName = "Hasan";
        String lastName = "Kir";

        String fullName = firstName +"\t"+ lastName;

        System.out.println("My first name is : " +firstName);
        System.out.println("My last name is : " + lastName);
        System.out.println("My full name is : " + fullName);





    }
}
