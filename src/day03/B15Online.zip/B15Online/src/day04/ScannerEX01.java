package day04;

import java.util.Scanner;

public class ScannerEX01 {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.println("How old are you? ");
        int age = input.nextInt();

        System.out.println(age + "... That's queit old!");



    }
}
