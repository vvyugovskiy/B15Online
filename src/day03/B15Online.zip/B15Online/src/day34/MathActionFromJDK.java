package day34;

public class MathActionFromJDK {

    public static void main(String[] args) {

        //String str = "Hello";

        int sum = Math.addExact(10,20);
        System.out.println("sum = " + sum);

       // int max = Math.max(34,90);
        System.out.println("max = " + Math.max(34,90));

    }
}
