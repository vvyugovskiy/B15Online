package introductionToJava.chapter1;

public class AreaAndPerimeterOfARectangle {

    public static void main(String[] args) {
        System.out.println("Area : "+4.5*7.9);
        System.out.println("Perimeter :"+(4.5+7.9+4.5+7.9));
    }
}
