package introductionToJava.chapter1;

public class ShowSyntaxErrors {
  public static void main(String[] args) {
    System.out.println("Welcome to Java");
  }
}
