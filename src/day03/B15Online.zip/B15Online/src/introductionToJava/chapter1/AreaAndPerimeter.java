package introductionToJava.chapter1;

public class AreaAndPerimeter {

    public static void main(String[] args) {

        double pi = 3.14;
        double radius=5.5;
        double perimeter = 2*radius * pi;
        double area = radius*radius *pi;
        System.out.println(perimeter);
        System.out.println(area);
    }
}
