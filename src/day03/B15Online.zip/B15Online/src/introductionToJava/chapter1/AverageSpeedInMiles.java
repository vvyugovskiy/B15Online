package introductionToJava.chapter1;

public class AverageSpeedInMiles {
    public static void main(String[] args) {
        double MilesHour = (14*60/45.5)/1.6;

        System.out.println(MilesHour);
    }
}
