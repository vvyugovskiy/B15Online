package day07;

public class RelationalOperator_with_variable {
    public static void main(String[] args) {

        // > >= < <= == != Relational Operator

        int nyNumber = 10;

        System.out.println(nyNumber>5);
        System.out.println(nyNumber<-19);
        System.out.println(nyNumber>=5);
        System.out.println(nyNumber>=8);
        System.out.println(nyNumber<=5);
        System.out.println(nyNumber>=8);

        System.out.println(nyNumber==5);
        System.out.println(nyNumber !=10);
        System.out.println(nyNumber !=6);

        char letterA = 'A';
        System.out.println(letterA + 1);
        System.out.println(" "+letterA + 1);
        //
    }
}
