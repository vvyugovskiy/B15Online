package day07;

public class RelationalOperator {
    public static void main(String[] args) {



        System.out.println(7>5);
        System.out.println(7<-19);
        System.out.println(5>=5);
        System.out.println(7>=8);
        System.out.println(4<=5);
        System.out.println(17>=8);

        System.out.println(5==5);
        System.out.println(6 !=10);
        System.out.println(6 !=6);



    }
}
