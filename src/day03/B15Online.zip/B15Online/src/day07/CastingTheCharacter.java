package day07;

public class CastingTheCharacter {

    public static void main(String[] args) {


        char grade = 'B';
        System.out.println(grade);

        int letterInNumber = 'B';
        //'B' is represents in ACHII table as 66
        // Char autom. widened to int
        // and stored as number
        System.out.println(letterInNumber);

        int letterInNumber2 = 'b';
        System.out.println(letterInNumber2);

        char myFirstChar = 100;
        System.out.println(myFirstChar);
         //___________________________

        int nameLetter1 = 'V';
        int nameLetter2 = 'L';
        int nameLetter3 = 'A';
        int nameLetter4 = 'D';
        int nameLetter5 = 'I';
        int nameLetter6 = 'S';
        int nameLetter7 = 'L';
        int nameLetter8 = 'A';
        int nameLetter9 = 'V';

        System.out.println(nameLetter1);
        System.out.println(nameLetter2);
        System.out.println(nameLetter3);
        System.out.println(nameLetter4);
        System.out.println(nameLetter5);
        System.out.println(nameLetter6);
        System.out.println(nameLetter7);
        System.out.println(nameLetter8);
        System.out.println(nameLetter9);

        System.out.println("Full name : " +nameLetter1+","+nameLetter2+","+nameLetter3+","+nameLetter4+","+nameLetter5+","+nameLetter6+","+nameLetter7+","+nameLetter8+","+nameLetter9);





    }
}
