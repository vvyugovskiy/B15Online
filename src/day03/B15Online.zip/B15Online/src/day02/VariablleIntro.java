package day02;

public class VariablleIntro {

    public static void main(String[] args) {
        //

        int offerCnt = 3 ;
        int CorollaMilage = 5000;
        int TVsize = 67;
        int myshoesize = 10;
        int myhousenumber = 1205;
        int myHouseZip = 29577;

        System.out.println("My Shoe Size = "+ myshoesize);
        System.out.println("My House Number = "+myhousenumber + " My Zip Code = " +myHouseZip);
        System.out.println(offerCnt);
        System.out.println("My Toyota Corolla's Milage is = " +CorollaMilage);
        System.out.println("TV Size = " + TVsize);



    }
}
