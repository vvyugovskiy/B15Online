package day02;

public class AboutME {

    public static void main(String[] args) {

        System.out.println("Hello Class");
    }
}
