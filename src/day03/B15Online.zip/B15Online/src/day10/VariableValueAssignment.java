package day10;

public class VariableValueAssignment {

    public static void main(String[] args) {

        int offerCount = 3;
        String message =""; // just declaring a variable

        if (offerCount >2 ) {
            message = "great job";
        }
        System.out.println(message);
    }
}
