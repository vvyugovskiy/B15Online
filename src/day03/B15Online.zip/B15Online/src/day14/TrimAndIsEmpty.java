package day14;

public class TrimAndIsEmpty {
    public static void main(String[] args) {

        String message = "  Repl is Coming !  ";
        System.out.println("message char count is "+message.length());
        System.out.println("message char count is "+message.trim());
        message = message.trim();
        System.out.println(message.length());
        // System.out.println(message.trim().length());









    }
}
