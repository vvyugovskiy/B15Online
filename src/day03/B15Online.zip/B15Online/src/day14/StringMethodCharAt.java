package day14;

public class StringMethodCharAt {
    public static void main(String[] args) {

        // charAt method of String
        // it will return
        String str = "VladislaV";
        System.out.print(str.charAt(0) + " ");
        System.out.print(str.charAt(1) + " ");
        System.out.print(str.charAt(2) + " ");
        System.out.print(str.charAt(3) + " ");
        System.out.print(str.charAt(4) + " ");
        System.out.print(str.charAt(5) + " ");
        System.out.print(str.charAt(6) + " ");
        System.out.print(str.charAt(7) + " ");
        System.out.println(str.charAt(8) + " ");

        System.out.println("____________________");

        System.out.println(str.charAt(0));
        System.out.println(str.charAt(1));
        System.out.println(str.charAt(2));
        System.out.println(str.charAt(3));
        System.out.println(str.charAt(4));
        System.out.println(str.charAt(5));
        System.out.println(str.charAt(6));
        System.out.println(str.charAt(7));
        System.out.println(str.charAt(8));

        String name = "Arya";
        char c1 = name.charAt(0);
        char c2 = name.charAt(1);
        char c3 = name.charAt(2);
        char c4 = name.charAt(3);
        System.out.println(c1+" "+c2+" "+c3+" "+c4);
    }
}
