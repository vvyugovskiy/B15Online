package day19;

public class SpeedAction {
    public static void main(String[] args) {

        // create 2 int var. Start end end
        // assume start>end
        // create a top loop to stimulate slow increase of the speed/
        // Ex. if starts 10 , end 27 : print 10-27

//         this is how we counted from 1 to 10
//        for(int i = 1 ; i <= 10 ; i++){
//            System.out.print(i + " " );
//        }

        int start = 5;
        int end = 19;
        System.out.print("you have started from speed--> ");
        for (int i = start; i <= end; i++){

            System.out.print(i+" ");

        }

    }
}
