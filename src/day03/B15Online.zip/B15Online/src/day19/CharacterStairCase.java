package day19;

public class CharacterStairCase {
    public static void main(String[] args) {
        String line = "";

        for (char iChar = 'A'; iChar <= 'Z'; iChar++) {

            line += iChar;
            System.out.println(line+" ");

        }
    }
}
