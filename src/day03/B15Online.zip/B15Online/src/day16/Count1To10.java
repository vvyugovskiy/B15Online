package day16;

public class Count1To10 {
    public static void main(String[] args) {

        int counter = 1;
        while (counter<=10){
            System.out.println("Counter v. : "+counter);

            ++counter;
        }
    }
}
