package day16;

public class WhileLoopPractice {
    public static void main(String[] args) {

        // print hello world 5 times
        // also keep the countof how many times you said hello

        int count = 1;
        System.out.println("Hello World");
        count++;
        System.out.println("__________________________");
        int cnt = 1;
        while (cnt<=5){
            System.out.println("Hello World");
            cnt++;
        }
        System.out.println("No more...");
    }
}
