package day16;

public class MonkeysJumping {
    public static void main(String[] args) {

        int monkeys = 5;
        while (monkeys>=1){
            System.out.println(+monkeys+ " little monkeys jumping on the bead");
            System.out.println("1 fell down and bumped his head,");
            System.out.println("Mama called the doctor and the doctor said,");
            System.out.println("No more monkeys jumping on the bed!");
            monkeys--;
        }
        System.out.println("Put those monkeys right to bed!");
    }
}
