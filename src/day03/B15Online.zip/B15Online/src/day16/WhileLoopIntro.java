package day16;

public class WhileLoopIntro {
    public static void main(String[] args) {

        int x = 100;
        while (x <= 105) {
            System.out.println("Hello World");
            x++;

        }
    }
}
