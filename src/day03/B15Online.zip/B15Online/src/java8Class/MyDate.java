package java8Class;

public class MyDate {

    int day;
    int year;
    int month;

    public MyDate() { }

    public MyDate(int m, int d, int y) { setDate(m,d,y); }

    public String toString() { return "MyDate : {" +month +"/"+day+"/"+year+"}"; }

    public void setDate(int m, int d, int y) {
        this.day = d;
        this.year = y;
        this.month = m;
    }

}
