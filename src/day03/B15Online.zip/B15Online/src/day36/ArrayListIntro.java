package day36;

import java.util.ArrayList;
import java.util.List;

public class ArrayListIntro {
    public static void main(String[] args) {
        // creating an ArrayList Object

        ArrayList<String> lst1 = new ArrayList<>();

        // IT WILL ONLY STORE OBJECTS
        //ArrayList<int> lst2 = new ArrayList<>();
        // Use wrapper type to create an Object with a number

        ArrayList<Integer> ist2 = new ArrayList<>();

        ArrayList<Long> ist3 = new ArrayList<>();

        ArrayList<Double> lst4 = new ArrayList<>();
        //Optionally
        List <String> myLst = new ArrayList<>();





    }
}
