package day36;

public class MethodWithParameter {
    public static void main(String[] args) {


        //addOneHundred(25);
        int num = 10;
        addOneHundred(num);
    }

    public static void addOneHundred (int x){
        x=x+100;
        System.out.println(x);
    }
}
