package day06;

public class oddOrEven {
    public static void main(String[] args) {

        int myNumber = 10;
        int yourNumber = 11;
        System.out.println("myNumber Remainder of dividing by 2 : " + myNumber%2);
        System.out.println("yourNumber Remainder of dividing by 2 : " + yourNumber%2);
        System.out.println("Adding yourNumber to myNumber : " + yourNumber+myNumber);
        System.out.println("Adding yourNumber to myNumber : " + (yourNumber+myNumber));
    }
}
