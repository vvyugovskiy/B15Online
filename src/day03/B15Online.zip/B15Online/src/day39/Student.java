package day39;

/**
 * any time you create a class. it will be a blueprint for object
 * And this class type can be a type for variable
 */
public class Student {

    // instance field / variable:
    String name;
    int age;
    char gender;

}

