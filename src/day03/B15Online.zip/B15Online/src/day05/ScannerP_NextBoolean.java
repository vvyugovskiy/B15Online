package day05;


import java.util.Scanner;

public class ScannerP_NextBoolean {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.println("Are you reacording ? ");
        boolean isRecording = input.nextBoolean();
        System.out.println("It is : " + isRecording);

        System.out.println("Are you are tired ? ");
        boolean isTired = input.nextBoolean();
        System.out.println("We are tired : "+isTired);

        /*
        create a programm that ask user for a F and converts's it to C

         */





    }
}
