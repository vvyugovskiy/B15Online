package day13;

import java.util.Scanner;

public class StringPractice {
    public static void main(String[] args) {

        int x = 10;
        int y = 12;
        Scanner scan = new Scanner(System.in);
        String S1 = new String("abc");
        String s2 = "hello";


    }
}
