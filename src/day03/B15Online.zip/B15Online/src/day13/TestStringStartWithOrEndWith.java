package day13;

public class TestStringStartWithOrEndWith {
    public static void main(String[] args) {


        String name = "Muge";

        // check if String starts with another String
        System.out.println(name.startsWith("Mu")   );
        System.out.println(name.startsWith("Mut"));
        // check if a String ends with another String
        System.out.println(name.endsWith("ge"));
        System.out.println(name.endsWith("g"));






    }
}
