package practice.mentors.Parvin;

public class MilkAlternatives {
    public static void main(String[] args) {

        // too many milks
        //looking into milk alternatives

        String[] milk = {"whole", "soy", "oat", "almond"};
        String[] milkBrands = {"Dean's", "Silk", "Oatly", "Greenway"};
        String[] milkContents = {"fat", "protein", "fiber", "sugar"};

        float[] caloriesFar = {8.0f, 4.5f, 7.0f, 2.5f};
        float[] caloriesProtein = {8.0f, 8.0f, 3.0f, 1.0f};
        float[] caloriesFiber = {0f, 2f, 3f, 1f};
        float[] caloriesSuger = {11f, 6f, 7f, 7f};
    }
}
