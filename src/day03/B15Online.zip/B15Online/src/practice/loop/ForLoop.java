package practice.loop;

public class ForLoop {
    public static void main(String[] args) {

     //  for (int i =1; i<=50;i++){
      //     if (i%2 !=0){
      //         System.out.print(i+", ");
      //     }

      //   }

       String []fruits = new String[3];
       fruits[0]="apples";
       fruits[1]="pears";
       fruits[2]="oranges";
       for (int k = 0; k<3; k++){
       //    System.out.println();
           System.out.println(fruits[k]);
       }

    }
}
