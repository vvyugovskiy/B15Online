package practice.office_Hours;

public class Practice_11_26_2 {
    public static void main(String[] args) {
        String season = "spring";

        /*

         */
        switch (season) {
            case "spring":
            case "summer":
            case "fall:":
                System.out.println("bear is active");
                break;
            case "winter":
                System.out.println("bear is asleep");
                break;

        }
    }

}
