package practice.office_Hours.Practice_2020_01_21;

public class BOATeams {

    // information -->>
    // instance variable
    int teamSize;
    String teamType;
    String teamName;
    String projectName;
    int officeLocation;

    // static variable
    static String companyName;

    // actions
    public void test() {
        System.out.println("The team is doing Demo");
    }

}
