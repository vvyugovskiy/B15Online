package practice.office_Hours.Practice_2020_01_21;

public class ScrumTeam extends BOATeams {

    // here we can focus only on ScrumTeam info

    String scrumMasterName;

    // actions
    public void standUp (){
        System.out.println("This Scrum team is attending a Stand Up team");
    }

}
