package practice.office_Hours;


public class Practice_11_14 {
    public static void main(String[] args) {


        String name = "Isil";
        System.out.println("my name is " + name);


        String city1 = "NYC";
        String city2 = "DC";
        int hours = 5;

        System.out.println("From NYC to DC is takes 5 hours by bus");
        System.out.println("From " + "NYC" + " to " + "DC" + " is takes " + 5 + " hours by bus");
        System.out.println("From " + city1 + " to " + city2 + " is takes " + hours + " hours by bus");

        System.out.println(city1+5);

        System.out.println(hours + 5);   // adding numbers to numbers will generate another number

        System.out.println("5"+5);  //will become a String

// Arithmetic operator
        System.out.println();










    }
}
