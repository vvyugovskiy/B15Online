package practice.office_Hours.Practice_2020_01_13;

public class AtTheBank2OfficeHour {
    public static void main(String[] args) {
        BankAccount ba1 = new BankAccount();
        ba1.balance = 5000;

        ba1.deposit(10000);
    }

}
