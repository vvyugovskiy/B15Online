package practice.office_Hours.Practice_2020_01_13;

public class Person {

    String firstName;
    String lastName;
    String DOB;

    public void printInfo (){
        System.out.println(String.format(""));
    }
}
