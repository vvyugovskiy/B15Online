package practice.office_Hours;

public class Practice_11_25 {
    public static void main(String[] args) {

        /*
        1. Assignment value

        2. relational | comparisom operator
        >= greater or equal
        <= less or equal          EX: 5<=4 --> false
        == checking for equality  EX: 51==52 --> false
        != checking for inequality EX: 51!=52 --> true

        3. Shorthand | compound operator
        += EX: x=x+10 --> x+=10;
                String text = "hello";
                text=text+"world"; -->text+="world";
        -= EX: x=x-10 --> x-=10;
        *= EX: x=x*10 --> x*=10;
        /= EX: x=x/10 --> x/=10;
        %= EX: x=x%10 --> x%%=10;
         */

    }

}
