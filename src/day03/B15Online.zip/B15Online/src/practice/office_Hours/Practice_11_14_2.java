package practice.office_Hours;


public class Practice_11_14_2 {
    public static void main(String[] args) {

// Arithmetic operator
        System.out.println(5+5);
        System.out.println("five + five is " + 5 + 5);  //


        char grade1 = 'A';
        char grade2 = 'B';
        char grade3 = 'C';
        char grade4 = 'D';








    }
}
