package practice.office_Hours;

// class is the most fundemental building block where you write code

public class Practice_11_12_Day14_OFFICE_HOUR_NESTED_IF {

    public static void main(String[] args) {

        // This is a comment and it will be ignored by compiler
        // i can write as many line i WANT
        // It could be plain english like this
        // or it could be valid statement like below
        // System.out.println("Hello B15");

//        System.out.println(" Hello world ");
//        System.out.println(" Hello B15 ");
//        System.out.println(" I am Akbar ");
        // commenting out short cut on mac is Command + /
        // commenting out short cut on windows is Command + / on mac

        //System.out.println(" I am your lead instructor ");

        int classStartingTime = 7;
        System.out.println(classStartingTime);

        int messageCount;
        messageCount = 400;

        System.out.println(messageCount);

        messageCount = 3000;
        System.out.println(messageCount);

//      naming rules

//      int 123abc = 78  ;    // can not start with number
        int abc123 = 78;
        int a123AC = 78;
        int _123abc = 78;
        int $12_ = 78;
        int $_ = 78;
        //  int offer count = 78 ; space can not be used
        // int offer%count = 78 ;  only $ and _ can be used

        int gameScore = 100;

        System.out.println("the game score now is : " + gameScore);


        System.out.println("the game score now is : " + gameScore + "       message count is " + messageCount);
        //System.out.println( "the game score now is : 100message count is 3000");

        //JAVA IS CASE SESITIVE @@!!!!!!!
        //System.out.println( "the game score now is : " +  GameScore   );


    }
}
