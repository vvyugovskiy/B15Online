package practice.office_Hours;

public class Practice_12_03 {
    public static void main(String[] args) {



    }
}
