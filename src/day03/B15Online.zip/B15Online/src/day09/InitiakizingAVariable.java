package day09;


import java.util.Scanner;

public class InitiakizingAVariable {
    public static void main(String[] args) {

        // int num ;
        // a var. inside a method must get initial value before its being used for the first time

        int num ;






    }
}