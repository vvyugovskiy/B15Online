package replit.$_051_100;

public class Evens_071 {
    public static void main(String[] args) {

        int x=2;
        while (x  <=100 ){
            if (x %2==0){
                System.out.println(x);
            }
            x++;
        }

    }
}
