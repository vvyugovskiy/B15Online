package replit.$_051_100;

import java.util.Scanner;

public class From0_100_081 {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
       // System.out.println("Enter Final Number");
        int n = 0;
        while (n<=100){
            System.out.println(n);
            n++;
        }
    }
}
