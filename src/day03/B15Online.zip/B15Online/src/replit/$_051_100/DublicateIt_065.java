package replit.$_051_100;

import java.util.Scanner;

public class DublicateIt_065 {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        String word1 = scan.next();
        String word2 = scan.next();
        //YOUR CODE HERE
        System.out.print(word1+word2+word2+word1);


    }
}
