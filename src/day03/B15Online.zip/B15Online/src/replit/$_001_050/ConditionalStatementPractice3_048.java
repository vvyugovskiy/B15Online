package replit.$_001_050;

import java.util.Scanner;

public class ConditionalStatementPractice3_048 {
    public static void main(String[] args) {
        Scanner inp = new Scanner(System.in);
        System.out.print("In:");
        String name = inp.nextLine();
        //DO NOT CHANGE ABOVE CODE!  Write your code below
if (name.equals("Chen")){
    System.out.println("teacher");
}else{
    System.out.println("student");
}



    }
}
