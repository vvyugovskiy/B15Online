package day45;

public class Fruit {

//    public Fruit (){
//       System.out.println("No arg Fruit constructor");
//    }

    public Fruit (String str){
        System.out.println("One arg Fruit constructor");
    }
}
