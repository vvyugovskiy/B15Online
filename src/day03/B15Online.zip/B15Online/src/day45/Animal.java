package day45;

public class Animal {

    public void speak (){
        System.out.println("Animal talk");
    }

}
