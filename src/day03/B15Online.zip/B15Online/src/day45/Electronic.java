package day45;

public class Electronic {

    String brand;
    static boolean useElectricity = true;

    public void showBrand() {
        System.out.println("Brand : " + brand);
    }

    public static void displayUseElectricity() {
        System.out.println("displaying useElectricity  " + useElectricity);
    }


}
